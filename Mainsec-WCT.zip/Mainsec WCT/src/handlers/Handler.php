<?php

interface Handler
{
    public function Process();
}
